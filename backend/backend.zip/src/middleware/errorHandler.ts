import { NextFunction, Request, Response } from 'express'
import { ZodError } from 'zod'
import { PrismaClientKnownRequestError, PrismaClientValidationError } from '@prisma/client/runtime/library'

export default function errorHandler(
  err: any,
  req: Request,
  res: Response,
  next: NextFunction
) {
  console.error('❌ Error:', err)

  // Validation errors (Zod)
  if (err instanceof ZodError) {
    return res.status(422).json({
      error: err.errors
    })
  }

  // Prisma "Not Found" errors
  if (err instanceof PrismaClientKnownRequestError && err.code === 'P2025') {
    return res.status(404).json({
      error: 'Not found'
    })
  }

  // Prisma validation errors
  if (err instanceof PrismaClientValidationError) {
    return res.status(400).json({
      error: err.message
    })
  }

  // Default server error
  res.status(500).json({
    error: 'Internal server error'
  })
}
