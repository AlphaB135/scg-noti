import { Router } from 'express'
import {
  createTeam, listTeams, updateTeam, deleteTeam,
  addMember, removeMember
} from '../modules/team/team.controller'

import { prisma } from '../prisma'  // สำหรับ query แบบตรงๆ ใน route

const router = Router()

// Team CRUD
router.post('/', createTeam)
router.get('/', listTeams)
router.put('/:id', updateTeam)
router.delete('/:id', deleteTeam)

// ดูสมาชิกทีม พร้อมข้อมูล profile
router.get('/:teamId/members', async (req, res) => {
  try {
    const { teamId } = req.params
    const members = await prisma.teamMember.findMany({
      where: { teamId },
      include: { 
        team: false,
        // ดึงข้อมูล EmployeeProfile ของ employeeId มา
        employee: {
          select: {
            userId: true,
            companyCode: true,
            employeeCode: true,
            firstName: true,
            lastName: true,
            position: true
          }
        }
      }
    })
    res.json(members)
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Failed to list team members' })
  }
})

// Team Members
router.post('/:teamId/members', addMember)
router.delete('/:teamId/members/:memberId', removeMember)

export default router
