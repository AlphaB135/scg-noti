// backend/src/routes/dashboard.ts
import { Router, Request, Response, NextFunction } from 'express'
import { prisma } from '../config/prismaClient'
import { authMiddleware } from '../middleware/auth.middleware'
import { authorize } from '../middleware/authz'
import type { RequestHandler } from 'express'

const router = Router()

router.get('/overview', 
  authMiddleware,
  authorize(['ADMIN']),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const [notifTotal, notifPending, notifApproved] = await Promise.all([
        prisma.notification.count(),
        prisma.notification.count({ where: { status: 'PENDING' } }),
        prisma.notification.count({ where: { status: 'APPROVED' } })
      ])

      const [apprTotal, apprPending, apprCompleted] = await Promise.all([
        prisma.approval.count(),
        prisma.approval.count({ where: { response: 'PENDING' } }),
        prisma.approval.count({ where: { response: 'APPROVE' } })
      ])

      const [userTotal, userActive] = await Promise.all([
        prisma.user.count(),
        prisma.user.count({ where: { status: 'ACTIVE' } })
      ])

      const recentActivity = await prisma.securityLog.findMany({
        orderBy: { createdAt: 'desc' },
        take: 5
      })

      const buildPct = (n: number, total: number) =>
        total > 0 ? Math.round((n / total) * 100) : 0

      res.json({
        notifications: {
          total: notifTotal,
          pending: notifPending,
          approved: notifApproved,
          approvedPercentage: buildPct(notifApproved, notifTotal)
        },
        approvals: {
          total: apprTotal,
          pending: apprPending,
          completed: apprCompleted,
          completedPercentage: buildPct(apprCompleted, apprTotal)
        },
        users: {
          total: userTotal,
          active: userActive,
          activePercentage: buildPct(userActive, userTotal)
        },
        recentActivity
      })
    } catch (error) {
      console.error('❌ [DASHBOARD ERROR]', error)
      next(error)
    }
  }
)

router.get('/metrics', 
  authMiddleware,
  authorize(['ADMIN']),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const lastWeek = new Date()
      lastWeek.setDate(lastWeek.getDate() - 7)

      const [notificationTrend, approvalTrend, userActivity] = await Promise.all([
        prisma.notification.groupBy({
          by: ['status', 'createdAt'],
          where: {
            createdAt: {
              gte: lastWeek
            }
          },
          _count: true
        }),
        
        prisma.approval.groupBy({
          by: ['response', 'createdAt'],
          where: {
            createdAt: {
              gte: lastWeek
            }
          },
          _count: true
        }),
        
        prisma.securityLog.groupBy({
          by: ['action', 'createdAt'],
          where: {
            createdAt: {
              gte: lastWeek
            }
          },
          _count: true
        })
      ])

      res.json({
        notificationTrend,
        approvalTrend,
        userActivity
      })
    } catch (error) {
      console.error('❌ [DASHBOARD ERROR]', error)
      next(error)
    }
  }
)

export default router
