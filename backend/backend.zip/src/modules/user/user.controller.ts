import { Request, Response } from 'express'
import { prisma } from '../../prisma'

/**
 * GET /api/users
 * คืนข้อมูล User พร้อม Profile (EmployeeProfile / AdminProfile)
 */
export const listUsers = async (_req: Request, res: Response) => {
  try {
    const users = await prisma.user.findMany({
      include: {
        employeeProfile: true,
        adminProfile: true,
      },
      orderBy: { createdAt: 'desc' }
    })
    res.json(users)
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Failed to fetch users' })
  }
}
