// 📁 backend/src/modules/notification/notification.service.ts
import { prisma } from '../../../prisma'   // ปรับ path ตามโครงการคุณ
import type { ListQueryOpts } from './notification.dto'

export async function list(opts: ListQueryOpts) {
  return prisma.notification.findMany({
    skip: opts.skip,
    take: opts.take,
    orderBy: { scheduledAt: 'asc' },
    // ถ้ามีเงื่อนไขอื่น เช่น recipientId ให้ใส่ใน where
    // where: { recipientId: opts.userId },
  })
}

export async function updateStatus(id: string, status: string) {
  return prisma.notification.update({
    where: { id },
    data: { status },
  })
}

export async function reschedule(
  id: string,
  dueDate: string,
  userId: string,
  reason: string
) {
  return prisma.notification.update({
    where: { id },
    data: {
      dueDate: new Date(dueDate),
      rescheduleReason: reason,
      rescheduledBy: { connect: { id: userId } },
      rescheduledAt: new Date(),
    },
  })
}
