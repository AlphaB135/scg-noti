// backend/src/modules/team/team.service.ts

import { prisma } from '../../prisma'
import { Team, TeamMember } from '@prisma/client'

import { TeamEvent } from './team.types'

class TeamService {
  /** สร้างทีมใหม่ */
  async createTeam(name: string, leaderId?: string): Promise<Team> {
    return prisma.team.create({
      data: { name, leaderId },
    })
  }

  /** ดึงทีมทั้งหมด พร้อม member list */
  async listTeams(): Promise<(Team & { members: TeamMember[] })[]> {
    return prisma.team.findMany({
      include: { members: true },
    })
  }

  /** อัปเดตชื่อหรือหัวหน้าทีม */
  async updateTeam(id: string, data: { name?: string; leaderId?: string }): Promise<Team> {
    return prisma.team.update({
      where: { id },
      data,
    })
  }

  /** ลบทีม */
  async deleteTeam(id: string): Promise<void> {
    await prisma.team.delete({ where: { id } })
  }

  /** เพิ่มพนักงานเข้า team (TeamMember) */
  async addMember(teamId: string, employeeId: string): Promise<TeamMember> {
    return prisma.teamMember.create({
      data: { teamId, employeeId },
    })
  }

  /** ลบพนักงานออกจากทีม */
  async removeMember(memberId: string): Promise<void> {
    await prisma.teamMember.delete({ where: { id: memberId } })
  }

  /** ดึง timeline ของทีม */
  async getTeamTimeline(teamId: string) {
    // Get team members
    const teamMembers = await prisma.teamMember.findMany({
      where: { teamId },
      select: { employeeId: true }
    })
    const memberIds = teamMembers.map(m => m.employeeId)

    // Get security logs for team members
    const securityLogs = await prisma.securityLog.findMany({
      where: { userId: { in: memberIds } },
      include: {
        user: {
          select: {
            id: true,
            employeeProfile: true,
            adminProfile: true
          }
        }
      },
      orderBy: { createdAt: 'desc' },
      take: 100 // Limit to recent events
    })

    // Get approvals related to team notifications
    const approvals = await prisma.approval.findMany({
      where: {
        notification: {
          recipients: {
            some: { groupId: teamId }
          }
        }
      },
      include: {
        user: {
          select: {
            id: true,
            employeeProfile: true,
            adminProfile: true
          }
        },
        notification: {
          select: {
            id: true,
            title: true
          }
        }
      },
      orderBy: { createdAt: 'desc' },
      take: 100
    })

    // Get notifications targeted to team
    const notifications = await prisma.notification.findMany({
      where: {
        recipients: {
          some: { groupId: teamId }
        }
      },
      include: {
        recipients: true
      },
      orderBy: { createdAt: 'desc' },
      take: 100
    })

    // Transform and combine events
    const timeline = [
      ...securityLogs.map(log => ({
        type: 'security' as const,
        actor: {
          id: log.user.id,
          name: log.user.employeeProfile?.firstName || log.user.adminProfile?.firstName || 'Unknown'
        },
        details: {
          action: log.action,
          ipAddress: log.ipAddress,
          userAgent: log.userAgent
        },
        timestamp: log.createdAt
      })),
      ...approvals.map(approval => ({
        type: 'approval' as const,
        actor: {
          id: approval.user.id,
          name: approval.user.employeeProfile?.firstName || approval.user.adminProfile?.firstName || 'Unknown'
        },
        details: {
          notificationId: approval.notification.id,
          notificationTitle: approval.notification.title,
          response: approval.response,
          comment: approval.comment
        },
        timestamp: approval.createdAt
      })),
      ...notifications.map(notification => ({
        type: 'notification' as const,
        actor: {
          id: notification.createdBy,
          name: 'System' // Could fetch creator's name if needed
        },
        details: {
          title: notification.title,
          message: notification.message,
          type: notification.type,
          category: notification.category
        },
        timestamp: notification.createdAt
      }))
    ].sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())

    return { timeline }
  }
}

export default new TeamService()
