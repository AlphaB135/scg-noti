// backend/src/modules/team/team.controller.ts
import { Request, Response } from 'express'
import TeamService from './team.service'

// POST   /api/teams
export const createTeam = async (req: Request, res: Response) => {
  const { name, leaderId } = req.body
  const team = await TeamService.createTeam(name, leaderId)
  res.status(201).json(team)
}

// GET    /api/teams
export const listTeams = async (_req: Request, res: Response) => {
  const teams = await TeamService.listTeams()
  res.json(teams)
}

// PUT    /api/teams/:id
export const updateTeam = async (req: Request, res: Response) => {
  const { id } = req.params
  const team = await TeamService.updateTeam(id, req.body)
  res.json(team)
}

// DELETE /api/teams/:id
export const deleteTeam = async (req: Request, res: Response) => {
  await TeamService.deleteTeam(req.params.id)
  res.status(204).send()
}


export const addMember = async (req: Request, res: Response) => {
  try {
    const { teamId } = req.params
    const { employeeId } = req.body
    const member = await TeamService.addMember(teamId, employeeId)
    res.status(201).json(member)
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Failed to add team member' })
  }
}

// DELETE /api/teams/:teamId/members/:memberId
export const removeMember = async (req: Request, res: Response) => {
  try {
    const { memberId } = req.params
    await TeamService.removeMember(memberId)
    res.status(204).send()
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Failed to remove team member' })
  }
}