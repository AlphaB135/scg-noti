import { Request, Response, NextFunction } from 'express'
import * as svc from './approval.service'
import { createApprovalSchema } from './approval.dto'

/**
 * GET /api/notifications/:id/approvals
 * คืนรายการ Approval ทั้งหมดของ Notification นั้น
 */
export async function listApprovals(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {  try {
    const { id: notificationId } = req.params
    const { page, size, status } = req.query

    const data = await svc.listApprovals(notificationId, {
      page: page ? parseInt(page as string) : undefined,
      size: size ? parseInt(size as string) : undefined,
      status: status as 'PENDING' | 'APPROVED' | 'REJECTED' | undefined
    })

    res.json(data)
    return
  } catch (err) {
    next(err)
  }
}

/**
 * POST /api/notifications/:id/approvals
 * สร้าง Approval ใหม่ (approve/reject) พร้อมคอมเมนต์
 */
export async function createApproval(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    // Debug headers
    console.log('Headers:', req.headers)
    console.log('Auth header:', req.headers.authorization)
    console.log('User object:', req.user)
    // Remove decoded and session logging since they're not available here
    
    const { id: notificationId } = req.params
    
    // Ensure user is authenticated
    if (!req.user?.id) {
      console.log('Authentication failed - user object:', req.user)
      res.status(401).json({ 
        error: 'Unauthorized - User not authenticated',
        detail: 'No user found in request'
      })
      return
    }

    const userId = req.user.id
    
    // Validate request body
    const input = createApprovalSchema.parse(req.body)
    
    const data = await svc.createApproval(notificationId, userId, input)
    res.status(201).json(data)
  } catch (err) {
    console.error('Full error details:', err)
    next(err)
  }
}

/**
 * GET /api/notifications/:id/approvals/metrics
 * ดึงสถิติการ approve ของ notification
 */
export async function getMetrics(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { id: notificationId } = req.params
    const metrics = await svc.getApprovalMetrics(notificationId)
    res.json(metrics)
  } catch (err) {
    next(err)
  }
}
