import { z } from 'zod'

export const createApprovalSchema = z.object({
  response: z.enum(['PENDING', 'APPROVED', 'REJECTED']),
  comment:  z.string().optional(),
})
export type CreateApprovalInput = z.infer<typeof createApprovalSchema>