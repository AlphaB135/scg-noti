import { prisma } from '../../prisma'
import type { CreateApprovalInput } from './approval.dto'

interface ApprovalQuery {
  page?: number
  size?: number
  status?: 'PENDING' | 'APPROVED' | 'REJECTED'
}

export async function listApprovals(notificationId: string, query?: ApprovalQuery) {
  if (!query) {
    return prisma.approval.findMany({
      where: { notificationId },
      orderBy: { createdAt: 'asc' },
    })
  }

  const page = Math.max(1, query.page || 1)
  const size = Math.min(100, Math.max(1, query.size || 10))
  const skip = (page - 1) * size

  // Build where clause
  const where = {
    notificationId,
    ...(query.status && { response: query.status })
  }

  // Get total count
  const total = await prisma.approval.count({ where })

  // Get paginated data
  const data = await prisma.approval.findMany({
    where,
    include: {
      user: {
        select: {
          id: true,
          email: true,
          employeeProfile: true,
          adminProfile: true
        }
      }
    },
    skip,
    take: size,
    orderBy: { createdAt: 'desc' }
  })

  return {
    data,
    meta: {
      total,
      page,
      size,
      pages: Math.ceil(total / size)
    }
  }
}

export async function getApprovalMetrics(notificationId: string) {
  const stats = await prisma.approval.groupBy({
    by: ['response'],
    where: { notificationId },
    _count: true
  })

  const metrics = {
    pending: 0,
    approved: 0,
    rejected: 0
  }

  stats.forEach(stat => {
    const count = stat._count
    switch (stat.response) {
      case 'PENDING':
        metrics.pending = count
        break
      case 'APPROVED':
        metrics.approved = count
        break
      case 'REJECTED':
        metrics.rejected = count
        break
    }
  })

  return metrics
}

export async function createApproval(
  notificationId: string,
  userId: string,
  input: CreateApprovalInput
) {
  // Validate inputs
  if (!notificationId) throw new Error('notificationId is required')
  if (!userId) throw new Error('userId is required')

  // Create approval
  return prisma.approval.create({
    data: {
      notification: { connect: { id: notificationId } },
      user: { connect: { id: userId } },
      response: input.response,
      comment: input.comment || '',
    },
    include: {
      user: true,
      notification: true
    }
  })
}
