import { prisma } from '../../prisma'
import { EmployeeProfile } from '@prisma/client'

class EmployeeService {
  /** ค้นหาพนักงาน ตามชื่อ-แผนก */
  async searchEmployees(keyword?: string): Promise<EmployeeProfile[]> {
    const where = keyword
      ? {
          OR: [
            { firstName: { contains: keyword, mode: 'insensitive' } },
            { lastName:  { contains: keyword, mode: 'insensitive' } },
            { position:  { contains: keyword, mode: 'insensitive' } }
          ]
        }
      : {}
    return prisma.employeeProfile.findMany({
      where,
      select: {
        userId: true,
        companyCode: true,
        employeeCode: true,
        firstName: true,
        lastName: true,
        position: true
      }
    })
  }
}

export default new EmployeeService()
