import { Request, Response } from 'express'
import EmployeeService from './employee.service'

/** GET /api/employees?search=kw */
export const searchEmployees = async (req: Request, res: Response) => {
  try {
    const { search } = req.query as { search?: string }
    const employees = await EmployeeService.searchEmployees(search)
    res.json(employees)
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Failed to search employees' })
  }
}
